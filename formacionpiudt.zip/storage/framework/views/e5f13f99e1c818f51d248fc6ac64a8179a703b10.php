<div class="row g-3" style="margin-bottom: 0" id="formReconocimiento">
    <div class="col-md-12">
        <pre class="form-control">
    DT(f) = PIU (f) = n G + F + I + T
    G(f) = Pp+Pf
    F(f) = S
    I(f) = CI+C
    T(f)= N + O

    El Desarrollo Territorial (DT) en su esencia, está en función de la Producción Intelectual Universitaria (PIU), que es el suma de las actividades de:
        - Gestión (G)
        - Formación (F)
        - Investigación (I)
        - Transferencia (T)

    La G está en función la suma de Producción pasada (Pp) y de la Producción futura o proyecta (Pf).
    La F está en función de lo que requiere la Sociedad (S)
    La I está en función de la suma de capacidad instalada (CI) y el conocimiento (C)
    La T está en función de la suma de necesidad y oportunidad de los emprendedores.</pre>
    </div>
    <div class="col-md-12">
        <pre class="form-control">
    Formación PIU (F)</pre>
    </div>
    <div class="col-md-12">
        <pre class="form-control">
    F(f) = S

    S: Lo que requiere la sociedad
    Captación de RDR. Brecha entre lo esperado y lo real en cada semestre o año. Colocación de egresados y graduados

        1 pto: De 0 a 25%
        2 pto: De 26% a 50%
        3 pto: De 51% a 75%
        4 pto: De 76% a 100%</pre>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\OC_FPIU\resources\views/formacion/reconocimiento.blade.php ENDPATH**/ ?>