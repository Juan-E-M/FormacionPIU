<?php $__env->startSection('content'); ?>
    <div class="content-grid">
        <div class="card" style="overflow-y: scroll; height: 100%">
            <div class="card-body">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Lista de Formacion <b>de PIU</b></h3>
                            <a href="<?php echo e(route('FormacionPIUTabs', ['idRegistro' => 0])); ?>" class="btn btn-success">
                                <i class="fa fa-plus-square"></i> <span>Agregar</span>
                            </a>
                        </div>
                        <hr/>
                        <div class="modal-body">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nombres y Apellidos</th>
                                    <th scope="col">Razon Social</th>
                                    <th scope="col">RUC</th>
                                    <th scope="col">Identificación de Universidad</th>
                                    <th scope="col">Programa de estudios</th>
                                    <th scope="col">Año de evaluación</th>
                                    <th scope="col">Fecha de evaluación</th>
                                    <th scope="col">Acciones</th>
                                    <th scope="col">Reporte</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $aportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($te->IdRegistro); ?></td>
                                        <td><?php echo e($te->NombresApellidos); ?></td>
                                        <td><?php echo e($te->RazonSocial); ?></td>
                                        <td><?php echo e($te->RUC); ?></td>
                                        <td><?php echo e($te->Universidad); ?></td>
                                        <td><?php echo e($te->ProgramaEstudios); ?></td>
                                        <td><?php echo e($te->AnioEval); ?></td>
                                        <td><?php echo e($te->FechaEval); ?></td>
                                        <td>
                                            <?php if(Auth::user()->id == $te->IdUsuario): ?>
                                                <a href="<?php echo e(route('FormacionPIUTabs', ['idRegistro' => $te->IdRegistro])); ?>"
                                                   class="btn btn-primary">
                                                    <i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i> Editar
                                                </a>
                                                <button onclick="EliminarFormacion(event, <?php echo e($te->IdRegistro); ?>)" class="btn btn-danger" data-toggle="modal">
                                                    <i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i> Eliminar
                                                </button>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('FormacionPIUTabs', ['idRegistro' => $te->IdRegistro])); ?>"
                                                   class="btn btn-primary">
                                                    <i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i> Ver
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('ReporteIndex', ['idRegistro' => $te->IdRegistro])); ?>" class="btn btn-secondary">
                                                <i class="fa fa-th" data-toggle="tooltip" title="Reporte"></i> Reporte
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function EliminarFormacion(e, idRegistro){
        e.preventDefault();
        let urlDelete = "<?php echo e(route('RegistroDelete', ':idRegistro')); ?>";
        urlDelete = urlDelete.replace(':idRegistro', idRegistro);

        Swal.fire({
            title: "¿Desea eliminar el Aporte?",
            showDenyButton: true,
            icon: 'question',
            confirmButtonText: 'Aceptar',
            denyButtonText: 'Cancelar',
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "post",
                    url: urlDelete,
                    data: { _token: $('#token').val() },
                    async: false,
                    success: function (result) {
                        if (result.success) {
                            Swal.fire({
                                position: 'center',
                                icon: 'success',
                                title: result.mensaje,
                                showConfirmButton: true
                            });
                            window.location.href = '<?php echo e(route("FormacionPIUIndex")); ?>';
                        }
                    },
                    error: function (error) {
                        Swal.fire({
                            position: 'center',
                            icon: 'error',
                            title: error.mensaje,
                            showConfirmButton: true
                        });
                        console.log(error)
                    }
                });
            }
        });
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OC_FPIU\resources\views/formacion/index.blade.php ENDPATH**/ ?>